<?php 
require (__DIR__."/../../model/etudiant/etu_model.php");
$mem = sou_liste();
require (__DIR__."/../../view/etudiant/list_sou_view.php");
?>