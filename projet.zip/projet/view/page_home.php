<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="/~u21607562/projet/public/css/style_commun.css">

</head>
<?php  
require (__DIR__."/header/header_home.php");
?>
<body>
	<section>

		<P> HOME PAGE </P>
		
	</section>

</body>
<?php
require ("footer.php");
?>
</html>